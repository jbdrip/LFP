/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diagrama_de_flujo;

import java.awt.Desktop;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Jose
 */
public class Tablas {
    
    FileWriter filewriter = null;
    PrintWriter printw = null;
    
    public void tabla_tokens(Token[] lista_tokens){
        try{
            filewriter = new FileWriter("TablaTokens.html");
            printw = new PrintWriter(filewriter);
            
            printw.println("<html>");
            printw.println("<head align=center>TOKENS</head>");
            printw.println("<body>");
            printw.println("<table border=" + '"' + 2 + '"' + "width=" + '"' + 850 + '"' + " align=center>");
            printw.println("<tr>");
            printw.println("<td>NO.</td>");
            printw.println("<td>TOKEN</td>");
            printw.println("<td>LEXEMA</td>");
            printw.println("<td>TIPO</td>");
            printw.println("<td>FILA</td>");
            printw.println("<td>COLUMNA</td>");
            printw.println("</tr>");
            
            for (Token token : lista_tokens) {
                if(token != null){
                    printw.println("<tr>");
                    printw.println("<td>" + token.correlativo + "</td>");
                    printw.println("<td>" + token.token + "</td>");
                    printw.println("<td>" + token.lexema + "</td>");
                    printw.println("<td>" + token.tipo + "</td>");
                    printw.println("<td>" + token.fila + "</td>");
                    printw.println("<td>" + token.columna + "</td>");
                    printw.println("</tr>");
                }
            }
            
            printw.println("</table>");
            printw.println("</body>");
            printw.println("</html>");
            
            printw.close();
            
            Desktop desktop;
            File file = new File("C:\\Users\\Jose\\Documents\\NetBeansProjects\\Diagrama_De_Flujo\\TablaTokens.html");
            
            if(Desktop.isDesktopSupported()){
                desktop = Desktop.getDesktop();
                try {
                    desktop.open(file);
                }
                catch (IOException ex) {
                    Logger.getLogger(Tablas.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        catch(IOException ex){
            System.out.println(ex);
        }
    }
    
    public void tabla_errores (Error[] lista_errores){
        try{
            filewriter = new FileWriter("TablaErrores.html");
            printw = new PrintWriter(filewriter);
            
            printw.println("<html>");
            printw.println("<head align=center>ERRORES</head>");
            printw.println("<body>");
            printw.println("<table border=" + '"' + 2 + '"' + "width=" + '"' + 850 + '"' + " align=center>");
            printw.println("<tr>");
            printw.println("<td>NO.</td>");
            printw.println("<td>ERROR</td>");
            printw.println("<td>DESCRIPCION</td>");
            printw.println("<td>FILA</td>");
            printw.println("<td>COLUMNA</td>");
            printw.println("</tr>");
            
            for (Error error : lista_errores) {
                if(error != null){
                    printw.println("<tr>");
                    printw.println("<td>" + error.correlativo + "</td>");
                    printw.println("<td>" + error.error + "</td>");
                    printw.println("<td>" + error.descripcion + "</td>");
                    printw.println("<td>" + error.fila + "</td>");
                    printw.println("<td>" + error.columna + "</td>");
                    printw.println("</tr>");
                }
            }
            
            printw.println("</table>");
            printw.println("</body>");
            printw.println("</html>");
            
            printw.close();
            
            Desktop desktop;
            File file = new File("C:\\Users\\Jose\\Documents\\NetBeansProjects\\Diagrama_De_Flujo\\TablaErrores.html");
            
            if(Desktop.isDesktopSupported()){
                desktop = Desktop.getDesktop();
                try {
                    desktop.open(file);
                }
                catch (IOException ex) {
                    Logger.getLogger(Tablas.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        catch(IOException ex){
            System.out.println(ex);
        }
    }
    
    public void salida(String[][] datos){
        String path = "";
        String pathAux = path;
        
        try{
            int contador = 0;
            String[] nombres;
            
            for(int i = 0; i < 500; i++){
                if(datos[9][i] != null){
                    contador++;
                }
            }
            
            nombres = new String[contador];
            contador = 0;
            
            for(int i = 1; i < 500; i++){
                if(datos[9][i] != null){
                    nombres[contador] = datos[0][i];
                    contador++;
                }
            }
            
            String nombres_espacio[] = new String[nombres.length];
            
            for(int i = 0; i < nombres.length; i++){
                nombres_espacio[i] = "";
                char[] espacio = nombres[i].toCharArray();
                for(int j = 0; j < espacio.length; j++){
                    if(Character.isLetter(espacio[j])){
                        nombres_espacio[i] += espacio[j];
                    }
                }
            }
            
            filewriter = new FileWriter("DiagramasDeFlujo.html");
            printw = new PrintWriter(filewriter);
            
            printw.println("<html>");
            printw.println("<body>");
            printw.println("<head align=center>"+nombres[0]+"</head>");
            for(int i = 0; i < nombres.length; i++){
                System.out.println(nombres_espacio[i]);
                path += nombres_espacio[i]+".jpg";
                System.out.println(path);
                printw.println("<center><img src="+'"'+path+'"'+"></center>");
                path = pathAux;
            }
            
            printw.println("</body>");
            printw.println("</html>");
            
            printw.close();
            
            Desktop desktop;
            File file = new File("C:\\Users\\Jose\\Documents\\NetBeansProjects\\Diagrama_De_Flujo\\DiagramasDeFlujo.html");
            
            if(Desktop.isDesktopSupported()){
                desktop = Desktop.getDesktop();
                try {
                    desktop.open(file);
                }
                catch (IOException ex) {
                    Logger.getLogger(Tablas.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        catch(IOException ex){
            System.out.println(ex);
        }
    }
}
