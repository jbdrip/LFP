/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diagrama_de_flujo;

/**
 *
 * @author Jose
 */
public class Error {
    
    int correlativo, fila, columna;
    String error, descripcion;
    
    public Error(int correlativo, int fila, int columna, String error, String descripcion){
        this.correlativo = correlativo;
        this.fila = fila;
        this.columna = columna;
        this.error = error;
        this.descripcion = descripcion;
    }
}
