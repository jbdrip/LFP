/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diagrama_de_flujo;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author Jose
 */
public class Graficador {
    
    public void crearDot(String[][] datos) {
        FileWriter fw = null;
        PrintWriter pw = null;
        
        String nombre = "";
        String aux ="";

        try {
            for(int i = 0; i < 500; i++){
                if(datos[9][i] != null){
                    aux = datos[0][i];
                    char[] espacios = datos[0][i].toCharArray();
                          for(int v = 0; v < espacios.length; v++){
                              if(Character.isLetter(espacios[v])){
                                  nombre+=espacios[v];
                              }
                          }
                }
            }
            fw = new FileWriter(nombre + ".dot");

            pw = new PrintWriter(fw);
            pw.println("digraph "+ nombre +" {");
            pw.println(genDot(datos));
            pw.println("}");
            pw.close();
        } 
        catch (IOException ex) {
            System.out.println(ex);
        } 
        finally {
            try {
                fw.close();
            } catch (IOException e) {

            }
        }

    }
    
    public String genDot(String[][] datos) {

        String cadena = "";

        for(int i = 0; i < 500; i++){
            
            if((datos[1][i] != null) && (datos[4][i] != null) && (datos[5][i] == null)){
                
                cadena += datos[1][i] + "->" + datos[4][i] + ";\n";
            }
            else if((datos[1][i] != null) && (datos[4][i] != null) && (datos[5][i] != null) && (datos[6][i] == null)){
                
                cadena += datos[1][i] + "->" + datos[4][i]+ ";\n";
                cadena += datos[1][i] + "->" + datos[5][i]+ ";\n";
            }
            else if((datos[1][i] != null) && (datos[4][i] != null) && (datos[5][i] != null) && (datos[6][i] != null) && (datos[7][i] == null)){
                
                cadena += datos[1][i] + "->" + datos[4][i]+ ";\n";
                cadena += datos[1][i] + "->" + datos[5][i]+ ";\n";
                cadena += datos[1][i] + "->" + datos[6][i]+ ";\n";
            }
            else if((datos[1][i] != null) && (datos[4][i] != null) && (datos[5][i] != null) && (datos[6][i] != null) && (datos[7][i] != null) && (datos[8][i] == null)){
                
                cadena += datos[1][i] + "->" + datos[4][i]+ ";\n";
                cadena += datos[1][i] + "->" + datos[5][i]+ ";\n";
                cadena += datos[1][i] + "->" + datos[6][i]+ ";\n";
                cadena += datos[1][i] + "->" + datos[7][i]+ ";\n";
            }
            else if((datos[1][i] != null) && (datos[4][i] != null) && (datos[5][i] != null) && (datos[6][i] != null) && (datos[7][i] != null) && (datos[8][i] != null) && (datos[9][i] == null)){
                
                cadena += datos[1][i] + "->" + datos[4][i]+ ";\n";
                cadena += datos[1][i] + "->" + datos[5][i]+ ";\n";
                cadena += datos[1][i] + "->" + datos[6][i]+ ";\n";
                cadena += datos[1][i] + "->" + datos[7][i]+ ";\n";
                cadena += datos[1][i] + "->" + datos[8][i]+ ";\n";
            }
            
            if((datos[1][i] != null) && (datos[2][i] != null) && (datos[3][i] != null)){
                
                if(datos[2][i].equals("Inicio") || datos[2][i].equals("Fin")){
                    
                    cadena += datos[1][i] + "[shape=oval,color=red,label=" + '"' + datos[3][i] + '"' +"];\n";
                }
                
                else if(datos[2][i].equals("Decision")){
                    
                    cadena += datos[1][i] + "[shape=diamond,color=yellow,label=" + '"' + datos[3][i] + '"' +"];\n";
                }
                
                else if(datos[2][i].equals("Actividad")){
                    
                    cadena += datos[1][i] + "[shape=box,color=green,label=" + '"' + datos[3][i] + '"' +"];\n";
                }
                
                else if(datos[2][i].equals("Conector")){
                    
                    cadena += datos[1][i] + "[shape=circle,color=blue,label=" + '"' + datos[3][i] + '"' +"];\n";
                }
            }
        }

        return cadena;
    }
    
    public void genImagen(String dirDot, String dirImagen) {

        String doPath = "C:\\Program Files (x86)\\Graphviz2.38\\bin\\dot.exe";
        String cmd = doPath + " -Tjpg " + dirDot + " -o " + dirImagen;

        try {
            Runtime.getRuntime().exec(cmd);
        } catch (IOException ex) {
            System.out.println("hola");
        }

    }
}
