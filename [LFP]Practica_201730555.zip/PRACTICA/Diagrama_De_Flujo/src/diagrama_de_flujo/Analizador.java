/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diagrama_de_flujo;

import java.awt.Color;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import static javafx.scene.paint.Color.color;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;

/**
 *
 * @author Jose
 */
public class Analizador {
    
    public int estado, contador, contador_, errores, tokens;
    public String lexema;
    
    public Token[] lista_tokens = new Token[3000];
    public Error[] lista_errores = new Error[2000];
    
    Graficador graficador = new Graficador();
    Tablas salida = new Tablas();
    
    public Analizador(){
        estado = 0;
        contador = 0;
        contador_ = 0;
        errores = 0;
        tokens = 0;
        lexema = "";
    }
    
    public void analisis_lexico(JTextArea editor){
        
        String[] filas = editor.getText().split("\n");
        for(int i = 0; i < filas.length; i++){
            
            char[] caracteres = filas[i].toCharArray();
            for(int j = 0; j < caracteres.length; j++){
                
                switch(estado){
                    
                    case 0: 
                        if(caracteres[j] == '"'){
                            lexema += caracteres[j];
                            estado = 1;
                        }
                        else if(Character.isUpperCase(caracteres[j])){
                            lexema += caracteres[j];
                            estado = 2;
                        }
                        else if(Character.isDigit(caracteres[j])){
                            lexema += caracteres[j];
                            estado = 3;
                        }
                        else if((caracteres[j] == '<') || (caracteres[j] == '>') || (caracteres[j] == '/') || (caracteres[j] == ',')){
                            lexema += caracteres[j];
                            int aux = j + 1;
                            if(aux == caracteres.length){
                                aceptacion_simbolos(i, j);
                            }
                            else{
                                estado = 4;
                            }
                        }
                        else if(Character.isWhitespace(caracteres[j])){
                            estado = 0;
                        }
                        else{
                            contador_++;
                            lista_errores[errores] = new Error(contador_, i + 1, j, Character.toString(caracteres[j]), "Elemento lexico desconocido.");
                            errores++;
                            lexema = "";
                            estado = 0;
                        }
                        break;
                        
                    case 1:
                        lexema += caracteres[j];
                        if(caracteres[j] == '"'){
                            estado = 5;
                        }
                        else{
                            estado = 1;
                        }
                        break;
                        
                    case 2:
                        int z = j;
                        do{
                            lexema += caracteres[j];
                            j++;
                        }
                        while(Character.isUpperCase(caracteres[j]));
                        
                        if(j > z){
                            j = j - 1;
                        }
                        
                        if((lexema.equals("DIAGRAMA")) || (lexema.equals("NOMBRE")) || (lexema.equals("COMPONENTE")) || (lexema.equals("CODIGO")) || (lexema.equals("TIPO")) || (lexema.equals("TEXTO")) || (lexema.equals("RELACION"))){
                            contador++;
                            lista_tokens[tokens] = new Token(contador, 2, lexema, "Reservada", i + 1, j);
                            tokens++;
                            lexema = "";
                            estado = 0;
                        }
                        else{
                            contador_++;
                            lista_errores[errores] = new Error(contador_, i + 1, j, lexema , "Lexema no perteneciente al lenguaje.");
                            errores++;
                            lexema = "";
                            estado = 0;
                        }
                        break;
                        
                    case 3:
                        do{
                            if(Character.isDigit(caracteres[j])){
                                lexema += caracteres[j];
                                j++;
                            }
                        }
                        while(Character.isDigit(caracteres[j]));
                        j = j - 1;
                        
                        contador++;
                        lista_tokens[tokens] = new Token(contador, 3, lexema, "Reservada", i + 1, j);
                        tokens++;
                        lexema = "";
                        estado = 0;
                        break;
                        
                    case 4:
                        aceptacion_simbolos(i, j);
                        j = j - 1;
                        estado = 0;
                        break;
                        
                    case 5:
                        contador++;
                        lista_tokens[tokens] = new Token(contador, 1, lexema, "Cadena", i + 1, j);
                        j = j - 1;
                        tokens++;
                        lexema = "";
                        estado = 0;
                        break;
                }
            }
        }
        
        
        
//        for (Token lista_token : lista_tokens) {
//            if (lista_token != null) {
//                Token aux = lista_token;
//                System.out.println(aux.correlativo + " " + aux.token + " " + aux.lexema + " " + aux.tipo + " " + aux.fila + " " + aux.columna);
//            }
//        }
    }
    
    public void aceptacion_simbolos(int i , int j){
        int tipo_simbolo = 0;
        String tipo = "";

        if(lexema.equals("/")){
            tipo_simbolo = 4;
            tipo = "Diagonal";
        }
        else if(lexema.equals("<")){
            tipo_simbolo = 5;
            tipo = "Menor que";
        }
        else if(lexema.equals(">")){
            tipo_simbolo = 6;
            tipo  = "Mayor que";
        }
        else if(lexema.equals(",")){
            tipo_simbolo = 7;
            tipo = "Coma";
        }

        contador++;
        lista_tokens[tokens] = new Token(contador, tipo_simbolo, lexema, tipo, i + 1, j);
        tokens++;
        lexema = "";
    }
    
    public void pintar_tokens(JTextArea area1, Token[] lista_tokens) {
        for (Token lista_token : lista_tokens) {
            
            if(lista_token != null){
                
                if (lista_token.lexema.length() >= 1) {
                    
                    if(lista_token.token == 1){
                        
                        DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.GREEN);
                        Highlighter h = area1.getHighlighter();
                        String text = area1.getText();
                        String caracteres = lista_token.lexema;
                        Pattern p = Pattern.compile("(?i)" + caracteres);
                        Matcher m = p.matcher(text);
                        
                        while (m.find()) {
                            
                            try {
                                
                                h.addHighlight(m.start(), m.end(), highlightPainter);
                            } 
                            catch (BadLocationException ex) {
                                
                                Logger.getLogger(Color.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                    else if(lista_token.token == 2){
                     
                        DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.BLUE);
                        Highlighter h = area1.getHighlighter();
                        String text = area1.getText();
                        String caracteres = lista_token.lexema;
                        Pattern p = Pattern.compile("(?i)" + caracteres);
                        Matcher m = p.matcher(text);
                        
                        while (m.find()) {
                            
                            try {
                                h.addHighlight(m.start(), m.end(), highlightPainter);
                            } 
                            catch (BadLocationException ex) {
                                
                                Logger.getLogger(Color.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                    else if(lista_token.token == 3){
                        
                        DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
                        Highlighter h = area1.getHighlighter();
                        String text = area1.getText();
                        String caracteres = lista_token.lexema;
                        Pattern p = Pattern.compile("(?i)" + caracteres);
                        Matcher m = p.matcher(text);
                        
                        while (m.find()) {
                            
                            try {
                                
                                h.addHighlight(m.start(), m.end(), highlightPainter);
                            } 
                            catch (BadLocationException ex) {
                                
                                Logger.getLogger(Color.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                    else if(lista_token.token == 4){
                        
                        DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.MAGENTA);
                        Highlighter h = area1.getHighlighter();
                        String text = area1.getText();
                        String caracteres = lista_token.lexema;
                        Pattern p = Pattern.compile("(?i)" + caracteres);
                        Matcher m = p.matcher(text);
                        
                        while (m.find()) {
                            
                            try {
                                
                                h.addHighlight(m.start(), m.end(), highlightPainter);
                            } 
                            catch (BadLocationException ex) {
                                
                                Logger.getLogger(Color.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                    else if(lista_token.token == 5 || lista_token.token == 6){
                        
                        DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.RED);
                        Highlighter h = area1.getHighlighter();
                        String text = area1.getText();
                        String caracteres = lista_token.lexema;
                        Pattern p = Pattern.compile("(?i)" + caracteres);
                        Matcher m = p.matcher(text);
                        
                        while (m.find()) {
                            
                            try {
                                
                                h.addHighlight(m.start(), m.end(), highlightPainter);
                            } 
                            catch (BadLocationException ex) {
                                
                                Logger.getLogger(Color.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                    else if(lista_token.token == 7){
                        
                        DefaultHighlighter.DefaultHighlightPainter highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.CYAN);
                        Highlighter h = area1.getHighlighter();
                        String text = area1.getText();
                        String caracteres = lista_token.lexema;
                        Pattern p = Pattern.compile("(?i)" + caracteres);
                        Matcher m = p.matcher(text);
                        
                        while (m.find()) {
                            
                            try {
                                
                                h.addHighlight(m.start(), m.end(), highlightPainter);
                            } 
                            catch (BadLocationException ex) {
                                
                                Logger.getLogger(Color.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                }
                else {
                    JOptionPane.showMessageDialog(area1, "la palabra a buscar no puede ser vacia");
                }
            }
        }
        
    }
    
    public String[][] obtener_datos(Token[] lista_tokens){
        
        int cont = 0;
        String[][] datos = new String[500][5];
        
        for(int i = 1; i < lista_tokens.length; i++){
            
            Token token = lista_tokens[i];
            
            if(token != null){
                
                Token ant = lista_tokens[i - 1];
                Token sig = lista_tokens[i + 1];
                Token aux;
                
                if(token.token == 2 && token.lexema.equals("DIAGRAMA")){
                    
                    if(ant.token == 5 && sig.token == 6){
                        datos[cont][0] = "diagrama";
                        cont++;
                    }
                }
                if(token.token == 2 && token.lexema.equals("NOMBRE")){
                    
                    if(ant.token == 5 && sig.token == 6){
                        aux = lista_tokens[i + 2];
                        if(aux.token == 1){
                            char[] cadena = aux.lexema.toCharArray();
                            datos[cont][0] = "nombre";
                            datos[cont][1] = "";
                            for(int j = 1; j < cadena.length - 1; j++){
                                datos[cont][1] += cadena[j];
                            }
                            System.out.println(datos[cont][1]);
                            cont++;
                        }
                    }
                    
                }
            }
        }
        return datos;
    }
    
    public void generar_imagenes(){
        
        lexema = "";
        int cont_datos = 1;
        String [][] datos;
        
        for(int i = 0; i < lista_tokens.length; i++){
            
            Token aux  = lista_tokens[i];
            
            if(aux != null){
                
                if(aux.token == 2 && aux.lexema.equals("DIAGRAMA")){
                
                    if(lista_tokens[i - 1].token == 5 && lista_tokens[i + 1].token == 6){
                    
                        datos = new String [15][500];
                        int z = i + 1;
                    
                        do{
                            if(lista_tokens[z].lexema.equals("NOMBRE")){
                                
                                if(lista_tokens[z - 1].token == 5 && lista_tokens[z + 1].token == 6){
                                
                                    if(lista_tokens[z + 2].token == 1){
                                    
                                        char[] comillas = lista_tokens[z + 2].lexema.toCharArray();
                                        lexema = "";
                                        
                                        for(int j = 1; j < comillas.length - 1; j++){
                                         
                                            lexema+= comillas[j];
                                        }
                                        
                                     datos[0][cont_datos] = lexema;
                                     datos[9][cont_datos] = "0";
                                    cont_datos++;
                                   }
                                }
                            }
                             else if(lista_tokens[z].lexema.equals("COMPONENTE")){
                            
                            if(lista_tokens[z - 1].token == 5 && lista_tokens[z + 1].token == 6){
                                
                                cont_datos++;
                                int x = z + 1;
                                
                                do{
                                    
                                    switch (lista_tokens[x].lexema) {
                                        
                                        case "CODIGO":
                                            
                                            if(lista_tokens[x - 1].token == 5 && lista_tokens[x + 1].token == 6){
                                                
                                                if(lista_tokens[x + 2].token == 3){
                                                    
                                                    datos[1][cont_datos] = lista_tokens[x + 2].lexema;
                                                }
                                            }   break;
                                            
                                        case "TIPO":
                                            
                                            if(lista_tokens[x - 1].token == 5 && lista_tokens[x + 1].token == 6){
                                                
                                                if(lista_tokens[x + 2].token == 1){
                                                    
                                                    char[] comillas = lista_tokens[x + 2].lexema.toCharArray();
                                                    lexema="";
                                        
                                                    for(int j = 0; j < comillas.length; j++){
                                         
                                                        if(Character.isLetter(comillas[j])){
                                                            lexema+= comillas[j];
                                                        }
                                                    }
                                                    
                                                    datos[2][cont_datos] = lexema;
                                                }
                                            }   break;
                                            
                                        case "TEXTO":
                                            
                                            if(lista_tokens[x - 1].token == 5 && lista_tokens[x + 1].token == 6){
                                                
                                                if(lista_tokens[x + 2].token == 1){
                                                    
                                                    char[] comillas = lista_tokens[x + 2].lexema.toCharArray();
                                                    lexema = "";
                                        
                                                    for(int j = 1; j < comillas.length - 1; j++){
                                         
                                                        lexema+= comillas[j];
                                                    }
                                                    
                                                    datos[3][cont_datos] = lexema;
                                                }
                                            }   break;
                                            
                                        case "RELACION":
                                            
                                            if(lista_tokens[x - 1].token == 5 && lista_tokens[x + 1].token == 6){
                                                
                                                if(lista_tokens[x + 2].token == 3){
                                                    
                                                    datos[4][cont_datos] = lista_tokens[x + 2].lexema;
                                                    
                                                    if(lista_tokens[x + 3].token == 7){
                                                        int q = x + 3;
                                                        int t = 4;
                                                    
                                                        do{
                                                            if(lista_tokens[q].token == 3){
                                                                
                                                                t++;
                                                                datos[t][cont_datos] = lista_tokens[q].lexema;
                                                            }

                                                            q ++;
                                                        }
                                                        while(!"<".equals(lista_tokens[q].lexema));
                                                    
                                                    }
                                                }
                                            }   break;
                                    }
                                    
                                    x++;
                                }
                                while(!"COMPONENTE".equals(lista_tokens[x].lexema));
                            }
                        }
                        z++;
                    }
                    while(!"DIAGRAMA".equals(lista_tokens[z].lexema));
                    
                    graficador.crearDot(datos);
                    String nombre = "";
                    for(int u = 0; u < 500; u++){
                        if(datos[9][u] != null){
                          char[] espacios = datos[0][u].toCharArray();
                          for(int v = 0; v < espacios.length; v++){
                              if(Character.isLetter(espacios[v])){
                                  nombre+=espacios[v];
                              }
                          }
                            System.out.println(nombre);
                        }
                    }
                    graficador.genImagen(nombre+".dot", nombre+".jpg");
                    salida.salida(datos);
                }
            }
            }
        }
    }
}
